import {  useState , useEffect } from 'react';
import axios from "axios";
import { Link } from 'react-router-dom';
import './Allusers.css';
import $ from 'jquery';
import Cookies from 'universal-cookie';
import { useNavigate } from "react-router-dom";
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
const cookies = new Cookies();

var navigate='';
function Allusers(){          
  navigate = useNavigate();
const [user,userState]= useState([]);
const [isLoading,setIsLoading] = useState(true);

  useEffect(() => {    
    var sessId=localStorage.getItem("userIds");
    console.log(sessId);
    
  if(sessId==''||sessId==undefined){
    navigate('/');
  }
    
    $('.mobile-bottom-nav').show();
    axios.post('http://192.168.136.100:9999/allusersdata',{id:localStorage.getItem('userIds')}).then((response) => {    
      setIsLoading(false);
      localStorage.getItem("userIds");
      if(response.data.allUsers!==''){
        userState(response.data.allUsers);
      }else{
      // navigate('/');
      }      

    });
  }, []);

  return (   
    <div className="container alluser_container" style={{position:"relative",height: "93vh",overflow: "scroll"}}>
    <div className="row" >
    {user.map(function (item,index){
            return <div key={item.receiver_id} className="col-12 tiles">
              <Link className="allusers_link clearfix row"
            to={{
              pathname:"/Chatwindow",
              search: "?id="+item.receiver_id, 
              state: { fromDashboard: true }
            }}>  
              <div className="col-3">
                <div className="pro_pics" style={{backgroundImage: 'url('+process.env.PUBLIC_URL+'"default.png")'}}></div>             
              </div>
              <div className="col-6 line-space msg-text"><strong >{item.name}</strong><p>{item.msg_content}</p></div>
              <div className="col-3 line-space"><p>Just now</p></div>
    
            </Link>
          </div>
           })}
    </div>
    </div>
        )

//     return (   
// <div className="container alluser_container" style={{position:"relative",height: "93vh",overflow: "scroll"}}>
// <div className="row" >
// {user.map(function (item,index){
//         return <div key={item.user_id} className="col-12 tiles">
//           <Link className="clearfix"
//         to={{
//           pathname:"/Chatwindow",
//           search: "?id="+item.user_id, 
//           state: { fromDashboard: true }
//         }}>  
//         <div className="row" >
//           <div className="col-3">
//              <img className="pro_pics" src={process.env.PUBLIC_URL+"default.png"} alt="" /> 
//           </div>
//           <div className="col-6 line-space msg-text"><strong >{item.name || <Skeleton /> }</strong><p>{item.msg_content || <Skeleton /> }</p></div>
//           <div className="col-3 line-space"><p>Just now</p></div>
//         </div>
//         </Link>
//       </div>
//        })}
// </div>
// </div>
//     )
    
      }


export default Allusers;