import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import { Routes, Route } from 'react-router-dom';
import Login from './Login';
import Settings from './Settings';
import Signup from './Signup';

// function testing(){
// $.ajax({
//   url:'http://localhost:3000/message',
//   data:{name:'messages'},
//   type:"post",
//   success:function(data){
//     if(data.msg==='success'){
//       window.location.href="/home";
//     }
//   }
// })
// }

function App() {
  return (
    
    <Routes>
    <Route
            path="/"
            element={ <Login /> }
        />

        <Route
            path="/Signup"
            element={ <Signup /> }
        />
        <Route
            path="/Settings"
            element={ <Settings /> }
        />
        {/* The next line is very important for the Navigate component to work */}                
    </Routes>

  );
}

export default App;