MDB5
Version: PRO (Nulled) 3.9.0

Documentation:
https://mdbootstrap.com/docs/standard/

How to Bypass PRO documentation (Read the tutorial on the forum):
https://babiato.co/resources/mdbootstrap-5-pro-mdb5-standard.13435/

From: LaBerhinga to Babiato with much love.
https://babiato.co/members/laberginha.91508/