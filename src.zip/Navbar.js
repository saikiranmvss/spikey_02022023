const Login = () => {
    return (

        <nav className="navbar">
            <h1>test</h1>
            </nav>

    )
}

export default Login;